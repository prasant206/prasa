<?php
/**
 * @package     Ecommerce/CreditLimit
 * @version     1.0.0
 * @author      CreditLimit Limited
 * @copyright   Copyright © 2021. All Rights Reserved.
 */
declare(strict_types=1);

namespace Ecommerce\CreditLimit\Block\Adminhtml\Media\Edit;

use Magento\Framework\View\Element\UiComponent\Control\ButtonProviderInterface;

/**
 * Creating back button
 */
class BackButton extends GenericButton implements ButtonProviderInterface
{
    /**
     * Get back button
     *
     * @return array
     */
    public function getButtonData()
    {
        return [
            'label' => __('Back'),
            'on_click' => sprintf("location.href = '%s';", $this->getBackUrl()),
            'class' => 'back',
            'sort_order' => 10
        ];
    }

    /**
     * Get URL for back (reset) button
     *
     * @return string
     */
    public function getBackUrl()
    {
        return $this->getUrl('*/*/');
    }
}
