<?php
/**
 * @package     Ecommerce\CreditLimit
 * @version     1.0.0
 * @author      Ecommerce Limited
 * @copyright   Copyright © 2021. All Rights Reserved.
 */
namespace Ecommerce\CreditLimit\Model;

use Ecommerce\CreditLimit\Model\ResourceModel\CreditLimit\CollectionFactory;

class FormDataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * @var array
     */
    protected $loadedData;
    /**
     * @var CollectionFactory
     */
    protected $collection;
    
    
    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $customerCollectionFactory
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $customerCollectionFactory,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $customerCollectionFactory->create();
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }
    
    /**
     * Get all options
     *
     * @return array
     */
    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
        $items = $this->collection->getItems();
        foreach ($items as $faqData) {
            $this->loadedData[$faqData->getData('entity_id')] = $faqData->getData();
        }
        return $this->loadedData;
    }
}
