<?php
/**
 * @package     Ecommerce/CreditLimit
 * @version     1.0.0
 * @author      Ecommerce Limited
 * @copyright   Copyright © 2021. All Rights Reserved.
 */
namespace Ecommerce\CreditLimit\Model;

use Magento\Ui\DataProvider\AbstractDataProvider;
use Ecommerce\CreditLimit\Model\ResourceModel\CreditLimit\CollectionFactory;
use Magento\Backend\Model\Auth\Session;

class DataProvider extends AbstractDataProvider
{
    /**
     * @var CollectionFactory
     */
    protected $collection;
    /**
     * @var Session
     */
    private $authSession;
    
    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param Session $authSession
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        Session $authSession,
        array $meta = [],
        array $data = []
    ) {
        $this->authSession = $authSession;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->collection = $collectionFactory->create();
    }
    
    /**
     * Get all options
     *
     * @return array
     */
    public function getCollection()
    {
        return $this->collection;
    }
    
    /**
     * Get all options
     *
     * @return array
     */
    public function getData()
    {
         return $this->getCollection()->toArray();
    }
}
