<?php
/**
 * @package     Ecommerce/CreditLimit
 * @version     1.0.0
 * @author      CreditLimit Limited
 * @copyright   Copyright © 2021. All Rights Reserved.
 */
namespace Ecommerce\CreditLimit\Model\ResourceModel;

class CreditLimit extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Define init
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('customer_credit_limit', 'entity_id');
    }
}
