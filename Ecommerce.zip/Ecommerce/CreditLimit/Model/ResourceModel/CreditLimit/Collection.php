<?php
/**
 * @package     Ecommerce/CreditLimit
 * @version     1.0.0
 * @author      Ecommerce Limited
 * @copyright   Copyright © 2021. All Rights Reserved.
 */
namespace Ecommerce\CreditLimit\Model\ResourceModel\CreditLimit;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'entity_id';
      /**
       * @var string
       */
    protected $_eventPrefix = 'customer_credit_limit_collection';
    /**
     * @var string
     */
    protected $_eventObject = 'customer_credit_limit_collection';
    

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            \Ecommerce\CreditLimit\Model\CreditLimit::class,
            \Ecommerce\CreditLimit\Model\ResourceModel\CreditLimit::class
        );
    }
}
