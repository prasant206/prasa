<?php
/**
 * @package     Ecommerce/CreditLimit
 * @version     1.0.0
 * @author      Infosys Limited
 * @copyright   Copyright © 2021. All Rights Reserved.
 */
namespace Ecommerce\CreditLimit\Model\Config\Source;

use Magento\Customer\Model\CustomerFactory;

class SetCreditTypeOptions extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    public function getAllOptions()
    {
        $this->_options= [];
        $this->_options[] = ['label' => __('-- Select --'), 'value'=> ''];
        $this->_options[] = ['value' => 1, 'label' => __('Credit')];
        $this->_options[] = ['value' => 2, 'label' => __('Debit')];
        
        return $this->_options;
    }
}
