<?php
/**
 * @package     Ecommerce/CreditLimit
 * @version     1.0.0
 * @author      Infosys Limited
 * @copyright   Copyright © 2021. All Rights Reserved.
 */
namespace Ecommerce\CreditLimit\Model\Config\Source;

use Magento\Customer\Model\CustomerFactory;

class SetCustomerId extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
    /**
     * @var customerCollection
     */
    protected $customerFactory;
    
    
    public function __construct(
        CustomerFactory $customerFactory
    ) {
        $this->customerFactory = $customerFactory;
    }
    /**
     * Get all options
     *
     * @return array
     */
    public function getAllOptions()
    {
        $collection  = $this->customerFactory->create()->getCollection()->getData();
        $this->_options[] = ['label' => __('-- Select --'), 'value'=> ''];
        foreach ($collection as $item) {
            $this->_options[] = ['label' => __($item['firstname']), 'value'=> $item['entity_id']];
        }
        return $this->_options;
    }
}
