<?php
/**
 * @package     Ecommerce\CreditLimit
 * @version     1.0.0
 * @author      CreditLimit Limited
 * @copyright   Copyright © 2021. All Rights Reserved.
 */
namespace Ecommerce\CreditLimit\Model;

class CreditLimit extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
    
    protected const CACHE_TAG = 'customer_credit_limit';
    
    /**
     * @var string
     */
    protected $cacheTag = 'customer_credit_limit';
    
    /**
     * @var string
     */
    protected $eventPrefix = 'customer_credit_limit';
    /**
     * Construct function
     *
     * @param \Ecommerce\CreditLimit\Model\ResourceModel\CreditLimit::class
     */
    protected function _construct()
    {
        $this->_init(\Ecommerce\CreditLimit\Model\ResourceModel\CreditLimit::class);
    }
     /**
      * Get identities
      *
      * @return array
      */
    public function getIdentities()
    {
        return [self::CACHE_TAG . '_' . $this->getId()];
    }
    /**
     * Get default value
     *
     * @return array
     */
    public function getDefaultValues()
    {
        $values = [];

        return $values;
    }
}
