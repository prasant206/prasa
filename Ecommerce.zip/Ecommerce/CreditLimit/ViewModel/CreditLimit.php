<?php
/**
 * @package     Ecommerce/CreditLimit
 * @version     1.0.0
 * @author      Ecommerce Limited
 * @copyright   Copyright © 2021. All Rights Reserved.
 */
namespace Ecommerce\CreditLimit\ViewModel;

use Magento\Framework\View\Element\Block\ArgumentInterface;
use Ecommerce\CreditLimit\Model\CreditLimitFactory;
use Magento\Customer\Model\CustomerFactory;
use Magento\Customer\Model\Session;

/**
 * Class CreditLimit
 */
class CreditLimit implements ArgumentInterface
{
    protected  $collection;
    
    protected  $customer;
    
    protected  $customerSession;
    
     /**
     * Constructer 
     * @param CreditLimitFactory $collection
     * @param CustomerFactory $customer
     * @param Session $customerSession
     */
    public function __construct(
        CreditLimitFactory $collection,
        CustomerFactory $customer,
        Session $customerSession
    ) {
        $this->collection = $collection;
        $this->customer = $customer;
        $this->customerSession = $customerSession;
    }
    
    /**
     * Get Customer Name
     *
     * @param int customerId
     * @return string
     */
    public function getCustomerName($customerId)
    {
        $customerName= $this->customer->create()->load($customerId)->getFirstname();
        return $customerName;
    }
    
     /**
     * Get Customer Credit Type
     *
     * @param int type
     * @return string
     */
    public function getCreditType($type)
    {
        $type = "Debit";
        if ($type == '1') {
            $type = "Credit";
        }
        return $type;
    }
    /**
     * Get Customer Collection By Customer Id Type
     *
     * @return array
     */
    public function getCollection()
    {
         $customerCreditModel = $this->collection->create();
         return $customerCreditModel->getCollection()
              ->addFieldToFilter('customer_id', $this->customerSession->getId())
              ->getData();
    }
}
