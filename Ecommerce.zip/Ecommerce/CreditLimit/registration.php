<?php

/**
 * @package   Ecommerce/CreditLimit
 * @version   1.0.0
 * @author    Ecommerce Limited
 * @copyright Copyright © 2021. All Rights Reserved.
 */

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Ecommerce_CreditLimit', __DIR__);
