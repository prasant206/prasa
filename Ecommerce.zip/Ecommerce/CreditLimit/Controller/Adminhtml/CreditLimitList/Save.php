<?php

/**
 * @package     Ecommerce/CreditLimit
 * @version     1.0.0
 * @author      Infosys Limited
 * @copyright   Copyright © 2021. All Rights Reserved.
 */

declare(strict_types=1);

namespace Ecommerce\CreditLimit\Controller\Adminhtml\CreditLimitList;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Message\ManagerInterface;
use Ecommerce\CreditLimit\Model\CreditLimitFactory;
use Magento\Framework\Stdlib\DateTime\DateTime;

class Save extends Action
{
    protected CreditLimitFactory $creditLimitFactory;
    
    protected DateTime $timezone;
    
    /**
     * @param Context $context
     * @param CreditLimitFactory $creditLimitFactory
     * @param DateTime $timezone
     */
    public function __construct(
        Context $context,
        CreditLimitFactory $creditLimitFactory,
        DateTime $timezone
    ) {
        parent::__construct($context);
        $this->creditLimitFactory = $creditLimitFactory;
        $this->timezone = $timezone;
    }

    /**
     * Save action
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $creditModel = $this->creditLimitFactory->create();
        $data = $this->getRequest()->getPost();
        
        try {
            if (!empty($data['entity_id'])) {
                $creditModel->setData('entity_id', $data['entity_id']);
            }
            
            $creditModel->setData('customer_id', $data['customer_id']);
            $creditModel->setData('credit_type', $data['credit_type']);
            $creditModel->setData('balance', $data['balance']);
            $creditModel->setData('transaction_date', $this->timezone->gmtDate());
            $creditModel->setData('remarks', $data['remarks']);
            $creditModel->save();
  
            //check for `back` parameter
            if ($this->getRequest()->getParam('back')) {
                return $resultRedirect->setPath('*/*/edit', [
                    'entity_id' => $creditModel->getId(),
                    '_current' => true, '_use_rewrite' => true
                ]);
            }
            $this->messageManager->addSuccessMessage(__('Customer Credit Limit Added Successfully.'));
            $this->_redirect('*/*');
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__($e->getMessage()));
        }
    }
}
